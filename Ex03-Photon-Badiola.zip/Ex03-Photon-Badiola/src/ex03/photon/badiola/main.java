/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03.photon.badiola;

/**
 *
 * @author local.admin
 */
public class main{

    
    public static void main(String[] args) {
       
    Song StayinAlive = new Song("Stayin Alive", 104.0);
    Singer joey = new Singer("joey", 0, 0.0, StayinAlive);    
    System.out.println(joey.name); 
    System.out.println(joey.noOfPerformances);
    System.out.println(joey.earnings);
    System.out.println(joey.favouriteSong.songName);
    }
    
}
