/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03.photon.badiola;

/**
 *
 * @author local.admin
 */
public class Singer{
    String name;
    Integer noOfPerformances;
    Double earnings;
    Song favouriteSong;

    public Singer(String na, Integer np, Double er, Song fs){
    name = na;
    noOfPerformances = np;
    earnings = er;
    favouriteSong = fs;

    }
}


