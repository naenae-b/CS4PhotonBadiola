/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03.photon.badiola;

/**
 *
 * @author local.admin
 */
public class Song {
    
    String songName;
    Double beatsPerMin;
    
    public Song(String sn, Double bpm){
    songName = sn;
    beatsPerMin = bpm;
    }
}
